% Abb. 4.9: Wirkstoff in Magen und Blut (Buch, Abschnitt 4.2, Gl. 4.9)
% dm/dt = -ka m,  db/dt = ka m - ke b  mit ka = 1, ke = 0.2 pro Stunde, m(0) = 4, b(0) = 0:  m(t) = 4 e^(-t), b(t) = 5 (e^(-0.2t) - e^(-t))
% (c) 2026 Philipp Kügler · Programm zum Buch „Dynamische Systeme in den Lebenswissenschaften“ · MIT-Lizenz (siehe LICENSE)
t = linspace(0, 20, 600);
m = 4 * exp(-t);
b = 5 * (exp(-0.2 * t) - exp(-t));
tmax = log(5) / 0.8;                                     % db/dt = 0: e^(-0.2t) = 5 e^(-t)
fprintf('höchster Spiegel im Blut b = %.3f mg nach t = %.3f h\n', 5 * (exp(-0.2 * tmax) - exp(-tmax)), tmax);
A = [-1 0; 1 -0.2];
fprintf('Eigenwerte von A: %g  %g\n', sort(eig(A)));
plot(t, m, 'Color', [0.43 0.04 0.12], 'LineWidth', 2); hold on
plot(t, b, 'Color', [0.89 0.44 0.49], 'LineWidth', 2); hold off
xlabel('t (Stunden)'); ylabel('Wirkstoff (mg)'); legend('Magen m(t)', 'Blut b(t)');
