# Fig. 2.5: Predator-prey model, the predators die out (book, Section 2.1, Eq. 2.3)
# u_{n+1} = (1 + r) u_n - r u_n^2 - gamma u_n v_n,  v_{n+1} = gamma u_n v_n  with r = 2.5, gamma = 1.1, u_0 = 0.5, v_0 = 0.2
# (c) 2026 Philipp Kügler · Program for the book "Dynamical Systems in the Life Sciences" · MIT License (see LICENSE)
r <- 2.5; gamma <- 1.1
N <- 40
u <- numeric(N + 1); v <- numeric(N + 1)
u[1] <- 0.5; v[1] <- 0.2                 # R counts from 1: u[1] is u_0
for (k in 1:N) {
  u[k + 1] <- (1 + r) * u[k] - r * u[k]^2 - gamma * u[k] * v[k]
  v[k + 1] <- gamma * u[k] * v[k]
}
cat("v_0, v_10, v_20, v_40 =", sprintf("%.4f", v[c(1, 11, 21, 41)]), " -> the predators die out\n")
cat("u_36 ... u_40 =", sprintf("%.3f", u[37:41]), "\n")

n <- 0:N
par(mfrow = c(1, 2))
plot(n, u, type = "o", lty = 2, pch = 16, col = rgb(0.43, 0.04, 0.12), ylim = range(c(u, v)), xlab = "n", ylab = "")
lines(n, v, type = "o", lty = 2, pch = 15, col = rgb(0.89, 0.44, 0.49))
legend("topright", legend = c("Prey u_n", "Predators v_n"), col = c(rgb(0.43, 0.04, 0.12), rgb(0.89, 0.44, 0.49)), pch = c(16, 15), lty = 2)
hell_dunkel <- colorRampPalette(c(rgb(1, 0.85, 0.85), rgb(0.43, 0.04, 0.12)))(N + 1)   # light: early, dark: late
plot(u, v, pch = 16, col = hell_dunkel, xlab = "Prey u_n", ylab = "Predators v_n")
points(u[1], v[1], pch = 16, cex = 1.5)
